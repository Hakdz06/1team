var book = document.getElementById("bookname");
var affiche = document.getElementById("zone_affichage_panier");
var div = document.getElementsByClassName("zone_livre");
div.getElementsByClassName('btn_supprimer')[0].addEventListener('click', supprDiv);
div.getElementsByClassName('cart-quantity-input')[0].addEventListener('change', quantite);

function ajouter(){
    nom_livre = book.value;
    createDiv(nom_livre);
    book.value = "";
}

// Création de la div lorsqu'on appuie sur ajouter
function createDiv(a){
    var newDiv = document.createElement('div');
    newDiv.classList.add('zone_livre');
    var insertion = `<p class='livre'>${a}</p>
                    <div class='orga'>
                    <input class="cart-quantity-input" type="number" value="1">
                    <input class='btn_supprimer btn-danger' type='button' value='Supprimer'>
                    </div>`
    if (a == ""){

    } else {
        // Ecrit seulement si la zonede texte n'est pas vide
        newDiv.innerHTML = insertion;
        affiche.appendChild(newDiv);
        // Ajout des écouteurs une fois la div publiée
        newDiv.getElementsByClassName('btn_supprimer')[0].addEventListener('click', supprDiv);
        newDiv.getElementsByClassName('cart-quantity-input')[0].addEventListener('change', quantite);
    } 
}

// Fonction attachée au body et permet d'ajouter avec enter
function enter(e){
    if (e.keyCode == 13){
        ajouter();
    }
}

// Suppression de la div en appuyant sur le bouton rouge supprimer
function supprDiv(event) {
    var buttonClicked = event.target;
    buttonClicked.parentElement.parentElement.remove();
}

// Empêcher d'aller à une quantité négatives
function quantite(event) {
    var input = event.target
    if (isNaN(input.value) || input.value <= 0) {
        input.value = 1
    }
}